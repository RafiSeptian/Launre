# Prerequisites

Before installing Voyager make sure you have installed one of the following versions of Laravel:
- Laravel 5.5
- Laravel 5.6
- Laravel 5.7
- Laravel 5.8
- Laravel 6

Additionally Voyager requires you to use PHP 7.2 or newer.