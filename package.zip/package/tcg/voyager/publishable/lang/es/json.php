<?php

return [
    'invalid'           => 'JSON inválido',
    'invalid_message'   => 'Parece que has introducido un JSON inválido.',
    'valid'             => 'JSON Válido',
    'validation_errors' => 'Errores de validación',
];
