<?php

return [
    'loggingin'    => 'Iniciando sesión',
    'signin_below' => 'Inicie sesión aquí:',
    'welcome'      => 'Bienvenido a Voyager. El administrador que le faltaba a Laravel',
];
