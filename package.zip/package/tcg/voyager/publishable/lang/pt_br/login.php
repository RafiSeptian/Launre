<?php

return [
    'loggingin'    => 'Iniciando sessão',
    'signin_below' => 'Iniciar sessão abaixo:',
    'welcome'      => 'Bem-vindo ao Voyager. O painel de administração que faltava para Laravel',
    'remember_me'  => 'Lembrar de mim',
];
