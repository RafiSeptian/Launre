<?php

return [
    'avatar'        => 'Profiilikuva',
    'edit'          => 'Muokkaa profiiliani',
    'edit_user'     => 'Muokkaa käyttäjää',
    'password'      => 'Salasana',
    'password_hint' => 'Jätä tyhjä jos et halua muuttaa',
    'role'          => 'Rooli',
    'user_role'     => 'Käyttäjän rooli',
];
