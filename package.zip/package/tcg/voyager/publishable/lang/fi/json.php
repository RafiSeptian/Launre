<?php

return [
    'invalid'           => 'Virheellinen JSON',
    'invalid_message'   => 'Näyttää siltä että JSON muoto oli virheellinen.',
    'valid'             => 'Kelpaava JSON',
    'validation_errors' => 'Muototarkistuksen virheet',
];
