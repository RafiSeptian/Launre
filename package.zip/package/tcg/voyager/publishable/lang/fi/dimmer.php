<?php

return [
    'page'           => 'Sivu|Sivua',
    'page_link_text' => 'Näytä kaikki sivut',
    'page_text'      => 'Sinulla on :count :string tietokannassa. Klikkaa alta näyttääksesi kaikki sivut.',
    'post'           => 'Kirjoitus|Kirjoitusta',
    'post_link_text' => 'Näytä kaikki kirjoitukset',
    'post_text'      => 'Sinulla on :count :string tietokannassa. Klikkaa alta näyttääksesi kaikki kirjoitukset.',
    'user'           => 'Käyttäjä|Käyttäjää',
    'user_link_text' => 'Näytä kaikki käyttäjät',
    'user_text'      => 'Sinulla on :count :string tietokannassa. Klikkaa alta näyttääksesi kaikki käyttäjät.',
];
