<?php

return [
    'field_password_keep'          => 'Leer lassen um das aktuelle Passwort zu behalten',
    'field_select_dd_relationship' => 'Stellen Sie sicher, dass Sie die entsprechende Relation in der :method Methode der :class Klasse setzen.',
    'type_checkbox'                => 'Check Box',
    'type_codeeditor'              => 'Code Editor',
    'type_file'                    => 'Datei',
    'type_image'                   => 'Bild',
    'type_radiobutton'             => 'Radio Button',
    'type_richtextbox'             => 'Rich Textbox',
    'type_selectdropdown'          => 'Select Dropdown',
    'type_textarea'                => 'Text Area',
    'type_textbox'                 => 'Text Box',
];
