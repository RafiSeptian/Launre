<?php

return [
    'by_pageview'            => 'nach Pageviews',
    'by_sessions'            => 'nach Sessions',
    'by_users'               => 'nach Benutzern',
    'no_client_id'           => 'Um Analytics zu sehen müssen Sie Ihre Google Analytics Client ID zu Ihren Einstellungen unter dem Schlüssel <code>google_analytics_client_id</code> hinzufügen. Holen Sie sich Ihren Key in der Google Developer Console:',
    'set_view'               => 'eine Ansicht wählen',
    'this_vs_last_week'      => 'Diese Woche im Vergleich zu letzter Woche',
    'this_vs_last_year'      => 'Dieses Jahr im Vergleich zum letzten Jahr',
    'top_browsers'           => 'Top Browser',
    'top_countries'          => 'Top Länder',
    'various_visualizations' => 'verschiedenartige Visualisierungen',
];
