<?php

return [
    'loggingin'    => 'Sedang login',
    'signin_below' => 'Sign In Dibawah:',
    'welcome'      => 'Selamat datang di Voyager. Admin untuk Laravel',
];
