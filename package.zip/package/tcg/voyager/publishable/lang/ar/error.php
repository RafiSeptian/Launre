<?php

return [
    'symlink_created_text'  => 'لقد أنشأنا للتو الاختصار symlink المفقود.',
    'symlink_created_title' => 'تم إنشاء الاختصار المفقود symlink إلى storage',
    'symlink_failed_text'   => 'فشلنا في إنشاء الاختصار المفقود في تطبيقك. يبدو أن مزود خدمة الاستضافة لديك لا يدعمه.',

    'symlink_failed_title'   => 'تعذر إنشاء الاختصار المفقود symlink إلى مجلد التخزين',
    'symlink_missing_button' => 'إصلاح المشكلة',
    'symlink_missing_text'   => 'لم نتمكن من العثور على اختصار symlink الى مجلد التخزين. قد يتسبب هذا في حدوث مشكلات في تحميل ملفات الوسائط من المتصفح.',

    'symlink_missing_title' => 'الاختصار symlink إلى مجلد التخزين مفقود',
];
