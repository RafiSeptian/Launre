<?php

return [
    'field_password_keep'          => 'Laissez vide pour garder le même',
    'field_select_dd_relationship' => 'Assurez-vous de configurer la relation appropriée dans la méthode :method de la classe :class.',
    'type_checkbox'                => 'Case à cocher',
    'type_codeeditor'              => 'Editeur de code',
    'type_file'                    => 'Fichier',
    'type_image'                   => 'Image',
    'type_radiobutton'             => 'Bouton radio',
    'type_richtextbox'             => 'Champ texte enrichi',
    'type_selectdropdown'          => 'Menu déroulant',
    'type_textarea'                => 'Zone de texte',
    'type_textbox'                 => 'Champ texte',
];
