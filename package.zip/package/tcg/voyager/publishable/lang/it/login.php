<?php

return [
    'loggingin'    => 'Collegati',
    'signin_below' => 'Accedi Qui Sotto:',
    'welcome'      => 'Benvenuti in Voyager. L\'Admin panel che mancava per Laravel',
];
