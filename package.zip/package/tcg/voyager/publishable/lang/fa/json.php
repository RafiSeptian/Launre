<?php

return [
    'invalid'           => 'جیسون نامعتبر',
    'invalid_message'   => 'به نظر می رسد جیسون معرفی شده دارای ایراد است.',
    'valid'             => 'جیسون معتبر',
    'validation_errors' => 'خطا در اعتبارسنجی',
];
