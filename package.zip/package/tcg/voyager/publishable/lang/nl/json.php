<?php

return [
    'invalid'           => 'Invalide JSON',
    'invalid_message'   => 'Het lijkt er op dat je wat invalide JSON hebt geïntroduceerd.',
    'valid'             => 'Valide JSON',
    'validation_errors' => 'Validatie fouten',
];
