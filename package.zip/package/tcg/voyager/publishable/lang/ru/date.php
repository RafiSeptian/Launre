<?php

return [
    'last_week' => 'На прошлой неделе',
    'last_year' => 'В прошлом году',
    'this_week' => 'На этой неделе',
    'this_year' => 'В этом году',
];
