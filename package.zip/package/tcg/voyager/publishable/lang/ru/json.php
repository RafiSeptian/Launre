<?php

return [
    'invalid'           => 'неверный формат JSON',
    'invalid_message'   => 'Введен неверный формат JSON',
    'valid'             => 'Верный формат JSON',
    'validation_errors' => 'Ошибки при проверке данных',
];
